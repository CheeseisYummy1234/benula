# Supported Sites on Nebula
Osana (Stable Build 83cae3b) by Nebula Services
- Google.com
- Youtube.com
- Discord.com 
- Discord.com AUDIO-ONLY Voice chat
- GitHub.com
- Bing.com
- search.brave.com
- 99% of all static sites 


UV (Stable Build 8153927) by Titanium Network
- Google.com
- Youtube.com
- GitHub.com
- Discord.com
- Discord.com AUDIO-ONLY Voice chat
- search.brave.com
- SealVM/ CollabVM
- GeforceNow (Partial Support)
- Now.gg (Partial Supprt)
- All static sites

Cyclone (Stable Build 664608d) by Nebula Services
- Google.com 
- Github.com (partial support)
- 90% of static websites
